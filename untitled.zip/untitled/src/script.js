function openChat() {
  alert("Chat Support coming soon ✅");
}

function changePassword() {
  alert("Password change option coming soon!");
}

function deactivate() {
  alert("Your account will be deactivated ❌");
}
